<!-- Footer -->
<footer class="py-5 bg-dark">
  <div class="container">
    <p class="m-0 text-center text-white">virtual bhai bros &copy;cse299project</p>
  </div>
  <!-- /.container -->
</footer>